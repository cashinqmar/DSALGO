# Projects Repository
List Of Projects
* Web Scraping
* Automation
* Excel Clone
* Whiteboard
* Phaser Game
## Quick Start
*  git clone https://github.com/Pep-DEV101/IP_Projects.git
*  cd IP_Projects
* npm install
