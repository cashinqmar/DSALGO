# References
## JavaScript Section
### File System(Node)
* Freecodecamp: Basic JS,Functional Programming,OOPS
* FileSystem Module: https://nodejs.dev/learn/the-nodejs-fs-module
* Require :https://medium.com/edge-coders/requiring-modules-in-node-js-everything-you-need-to-know-e7fbd119be8
### WebScrapping
* Cheerio: http://zetcode.com/javascript/cheerio/
* https://www.npmjs.com/package/cheerio
#### Puppeteer  
  * https://flaviocopes.com/puppeteer/
	* https://nitayneeman.com/posts/getting-to-know-puppeteer-using-practical-examples/
  * https://peter.sh/experiments/chromium-command-line-switches/
### Async JS
* First Three chapters:https://github.com/getify/You-Dont-Know-JS/blob/1st-ed/async%20&%20performance/README.md#you-dont-know-js-async--performance
